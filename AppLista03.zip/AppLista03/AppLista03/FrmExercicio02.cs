﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio02 : Form
    {
        public FrmExercicio02()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Pegar dados da tela
            float vlrPago = float.Parse(txtVlrPagar.Text);
            float vlrLitro = float.Parse(txtVlrLitro.Text);
            float totalLitros;

            //Calculo
            totalLitros = vlrPago / vlrLitro;

            lblResultado.Text = "Abasteceu com " + totalLitros.ToString("C");


        }
    }
}
